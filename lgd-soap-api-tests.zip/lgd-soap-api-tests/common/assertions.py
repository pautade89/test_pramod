from __future__ import annotations
import re
from .xml_utils import has_soap_fault, xpath_text


def assert_http_200(status_code: int, body: str):
    assert status_code == 200, f"Expected HTTP 200, got {status_code}\nResponse:\n{body}"


def assert_no_soap_fault(root, raw_xml: bytes):
    assert not has_soap_fault(root), f"SOAP Fault found:\n{raw_xml.decode('utf-8', errors='ignore')}"


def assert_success_failure(root):
    """Success/Failure assertion from SOAP response fields.

    Requires:
      - topLevelStatusCode present
      - topLevelStatusSeverity present and not containing 'error'/'fail'
    """
    sev = xpath_text(root, "string(//*[local-name()='topLevelStatusSeverity'])")
    code = xpath_text(root, "string(//*[local-name()='topLevelStatusCode'])")

    assert code.strip() != "", "topLevelStatusCode is missing/empty"
    assert sev.strip() != "", "topLevelStatusSeverity is missing/empty"

    sev_l = sev.strip().lower()
    assert ("error" not in sev_l) and ("fail" not in sev_l), f"Failure returned: severity={sev} code={code}"

    return {"topLevelStatusCode": code.strip(), "topLevelStatusSeverity": sev.strip()}


def assert_final_lgd_rate(root):
    """finalLGDRate assertion: must exist and be numeric."""
    rate = xpath_text(root, "string(//*[local-name()='finalLGDRate'][1])")
    assert rate.strip() != "", "finalLGDRate is missing/empty"

    assert re.fullmatch(r"-?\d+(\.\d+)?", rate.strip()) is not None, f"finalLGDRate not numeric: {rate}"
    return rate.strip()
