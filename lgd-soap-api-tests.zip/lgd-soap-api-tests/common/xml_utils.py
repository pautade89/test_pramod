from __future__ import annotations
from lxml import etree


def parse_xml(xml_bytes: bytes):
    return etree.fromstring(xml_bytes)


def xpath_text(root, expr: str, namespaces: dict | None = None) -> str:
    result = root.xpath(expr, namespaces=namespaces)
    if isinstance(result, list):
        if not result:
            return ""
        first = result[0]
        if hasattr(first, "text"):
            return first.text or ""
        return str(first)
    return str(result)


def has_soap_fault(root) -> bool:
    return len(root.xpath("//*[local-name()='Fault']")) > 0
