from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, StrictUndefined


@dataclass(frozen=True)
class TemplateEngine:
    root: Path

    def render(self, template_rel_path: str, context: dict) -> str:
        env = Environment(
            loader=FileSystemLoader(str(self.root)),
            undefined=StrictUndefined,
            autoescape=False,
            keep_trailing_newline=True,
        )
        template = env.get_template(template_rel_path)
        return template.render(**context)
