from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import os
import yaml


@dataclass(frozen=True)
class EndpointConfig:
    base_url: str
    service_path: str
    soap_action: str = "http://www.rbc.com/lgdengine/ws/operation"
    timeout: int = 30
    verify_tls: bool = True


def load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_endpoint_config(config_file: Path, overrides: dict | None = None) -> EndpointConfig:
    data = load_yaml(config_file)
    overrides = overrides or {}

    base_url = overrides.get("base_url") or os.getenv("BASE_URL") or data["base_url"]
    service_path = overrides.get("service_path") or os.getenv("SERVICE_PATH") or data["service_path"]

    verify_override = overrides.get("verify_tls")

    return EndpointConfig(
        base_url=str(base_url).rstrip("/"),
        service_path="/" + str(service_path).strip("/"),
        soap_action=overrides.get("soap_action") or data.get("soap_action", "http://www.rbc.com/lgdengine/ws/operation"),
        timeout=int(overrides.get("timeout") or data.get("timeout", 30)),
        verify_tls=bool(verify_override if verify_override is not None else data.get("verify_tls", True)),
    )
