from __future__ import annotations
import requests
from dataclasses import dataclass
from typing import Optional


@dataclass
class SoapResponse:
    status_code: int
    headers: dict
    text: str
    content: bytes
    elapsed_ms: int


class SoapClient:
    def __init__(self, timeout: int = 30, verify_tls: bool = True, cert: Optional[str] = None):
        self.session = requests.Session()
        self.timeout = timeout
        self.verify_tls = verify_tls
        self.cert = cert

    def post_xml(self, url: str, xml_body: str, soap_action: str | None = None, extra_headers: dict | None = None) -> SoapResponse:
        headers = {"Content-Type": "text/xml; charset=utf-8"}
        if soap_action:
            headers["SOAPAction"] = soap_action
        if extra_headers:
            headers.update(extra_headers)

        resp = self.session.post(
            url,
            data=xml_body.encode("utf-8"),
            headers=headers,
            timeout=self.timeout,
            verify=self.verify_tls,
            cert=self.cert,
        )

        return SoapResponse(
            status_code=resp.status_code,
            headers=dict(resp.headers),
            text=resp.text,
            content=resp.content,
            elapsed_ms=int(resp.elapsed.total_seconds() * 1000),
        )
