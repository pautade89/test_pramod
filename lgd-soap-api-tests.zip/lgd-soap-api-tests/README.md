# LGD SOAP API Tests (pytest framework)

This repository contains **two independent pytest SOAP API test suites**:
- `ccms/`  (CCMS scenarios)
- `synergy/` (Synergy scenarios)

Shared utilities are in `common/`.

## Dynamic Endpoints (QA/UAT)
Run with `--env qa|uat`. Endpoint configs are stored per project:
- `ccms/config/endpoints.qa.yaml`, `ccms/config/endpoints.uat.yaml`
- `synergy/config/endpoints.qa.yaml`, `synergy/config/endpoints.uat.yaml`

Configured from your input:
- QA WSDL: `https://gueqlvarlg0001.saifg.rbc.com:8443/LGDEngine/LGDRateService?wsdl`
- UAT WSDL: `https://paramapp.saifg.rbc.com:8443/LGDEngine/LGDRateService?wsdl`

> Runtime request URL is the service URL without `?wsdl`.

## Install
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e .
```

## Run (pytest-html + Allure)
### CCMS Smoke on QA
```bash
pytest -m "ccms and smoke" --env qa   --html=reports/ccms-report.html --self-contained-html   --alluredir=reports/allure-results/ccms
```

### Synergy Smoke on UAT
```bash
pytest -m "synergy and smoke" --env uat   --html=reports/synergy-report.html --self-contained-html   --alluredir=reports/allure-results/synergy
```

### Build Allure HTML (requires Allure CLI)
```bash
allure generate reports/allure-results/ccms -o reports/allure-report/ccms --clean
allure open reports/allure-report/ccms
```

## Assertions implemented (requested)
Each test validates:
1) HTTP status code = 200
2) Success/Failure using `topLevelStatusSeverity` + `topLevelStatusCode`
3) `finalLGDRate` exists and is numeric
