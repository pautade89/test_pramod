from __future__ import annotations
import pytest
import allure
from pathlib import Path

from common.config import load_endpoint_config
from common.soap_client import SoapClient
from common.template_engine import TemplateEngine


def pytest_addoption(parser):
    parser.addoption("--env", action="store", default="qa", choices=["qa", "uat"], help="Target environment")
    parser.addoption("--base-url", action="store", default=None, help="Override base_url")
    parser.addoption("--service-path", action="store", default=None, help="Override service_path")
    parser.addoption("--insecure", action="store_true", help="Disable TLS verification")


def pytest_collection_modifyitems(config, items):
    # Auto-add marker 'qa' or 'uat' based on --env
    env_name = config.getoption("--env")
    env_marker = getattr(pytest.mark, env_name)
    for item in items:
        item.add_marker(env_marker)


@pytest.fixture(scope="session")
def env(request) -> str:
    return request.config.getoption("--env")


@pytest.fixture(scope="session")
def endpoint_cfg(request, env):
    cfg_file = Path(__file__).resolve().parents[1] / "config" / f"endpoints.{env}.yaml"
    overrides = {
        "base_url": request.config.getoption("--base-url"),
        "service_path": request.config.getoption("--service-path"),
        "verify_tls": False if request.config.getoption("--insecure") else None,
    }
    return load_endpoint_config(cfg_file, overrides=overrides)


@pytest.fixture(scope="session")
def soap_client(endpoint_cfg):
    return SoapClient(timeout=endpoint_cfg.timeout, verify_tls=endpoint_cfg.verify_tls)


@pytest.fixture(scope="session")
def template_engine():
    template_root = Path(__file__).resolve().parents[1] / "data" / "templates"
    return TemplateEngine(root=template_root)


@pytest.fixture
def service_url(endpoint_cfg) -> str:
    return f"{endpoint_cfg.base_url}{endpoint_cfg.service_path}"


@pytest.fixture
def attach_allure():
    def _attach(name: str, content: str, mime: str = "text/xml"):
        if mime == "text/xml":
            allure.attach(content, name=name, attachment_type=allure.attachment_type.XML)
        else:
            allure.attach(content, name=name, attachment_type=allure.attachment_type.TEXT)
    return _attach
