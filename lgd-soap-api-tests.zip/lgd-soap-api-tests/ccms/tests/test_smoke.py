from __future__ import annotations
import uuid
from pathlib import Path
import yaml
import pytest
import allure

from common.xml_utils import parse_xml
from common.assertions import assert_http_200, assert_no_soap_fault, assert_success_failure, assert_final_lgd_rate


@allure.epic("LGDRateService")
@allure.feature("CCMS")
@pytest.mark.ccms
@pytest.mark.smoke
@pytest.mark.positive
@pytest.mark.parametrize("case_name", ["getlgdrate_smoke", "getlgdrate_transform_smoke"])
def test_smoke(case_name, service_url, endpoint_cfg, soap_client, template_engine, attach_allure):
    dataset_path = Path(__file__).resolve().parents[1] / "data" / "datasets" / "smoke.yaml"
    ds = yaml.safe_load(dataset_path.read_text(encoding="utf-8"))
    case = next(c for c in ds["cases"] if c["name"] == case_name)

    payload = case["data"]
    if payload.get("reqUID") == "AUTO":
        payload["reqUID"] = str(uuid.uuid4())

    xml_body = template_engine.render(case["template"], payload)
    attach_allure("Request XML", xml_body, "text/xml")

    resp = soap_client.post_xml(service_url, xml_body, soap_action=endpoint_cfg.soap_action)
    attach_allure("Response XML", resp.text, "text/xml")

    # Requested assertions:
    assert_http_200(resp.status_code, resp.text)

    root = parse_xml(resp.content)
    assert_no_soap_fault(root, resp.content)

    status = assert_success_failure(root)
    allure.attach(str(status), name="Success/Failure", attachment_type=allure.attachment_type.TEXT)

    rate = assert_final_lgd_rate(root)
    allure.attach(rate, name="finalLGDRate", attachment_type=allure.attachment_type.TEXT)
